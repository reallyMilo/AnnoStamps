"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const sharp_1 = __importDefault(require("sharp"));
const stream_1 = require("stream");
const util_1 = __importDefault(require("util"));
const s3 = new client_s3_1.S3Client({ region: 'eu-central-1' });
const handler = async (event) => {
    console.log('Reading options from event:\n', util_1.default.inspect(event, { depth: 5 }));
    const srcBucket = event.Records[0].s3.bucket.name;
    // TODO: add meta tags to the object for path and file name on client upload
    const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const dstBucket = srcBucket;
    const startIdx = srcKey.lastIndexOf('/');
    const lastIndex = srcKey.lastIndexOf('.');
    const [path, filename] = [
        srcKey.slice(0, startIdx),
        srcKey.slice(startIdx + 1, lastIndex),
    ];
    let content_buffer = null;
    let metadata = null;
    try {
        const params = {
            Bucket: srcBucket,
            Key: srcKey,
        };
        const response = await s3.send(new client_s3_1.GetObjectCommand(params));
        console.log('Metadata:\n', util_1.default.inspect(response.Metadata, { depth: 5 }));
        const stream = response.Body;
        metadata = response.Metadata;
        if (stream instanceof stream_1.Readable) {
            content_buffer = Buffer.concat(await stream.toArray());
        }
        else {
            throw new Error('Unknown object stream type');
        }
    }
    catch (error) {
        console.error(error);
        return;
    }
    const BREAKPOINTS = {
        large: 1024,
        medium: 768,
        small: 640,
        thumbnail: 250,
    };
    try {
        const { height, size, width } = await (0, sharp_1.default)(content_buffer).metadata();
        for (const [key, value] of Object.entries(BREAKPOINTS)) {
            const breakpoint = value;
            const dstKey = `responsive/${path}/${key}_${filename}.webp`;
            const imageBuffer = await (0, sharp_1.default)(content_buffer)
                .resize(breakpoint, null, {
                fit: 'inside',
            })
                .toFormat('webp')
                .toBuffer();
            const destinationParams = {
                Body: imageBuffer,
                Bucket: dstBucket,
                ContentType: 'image',
                Key: dstKey,
                Metadata: { ...metadata, imageVariant: `${key}Url` },
            };
            //TODO: attach size,width,height meta tags to object on client upload.
            //@ts-expect-error undefined
            if (breakpoint < width || breakpoint < height) {
                await s3.send(new client_s3_1.PutObjectCommand(destinationParams));
                console.log('Successfully resized ' +
                    srcBucket +
                    '/' +
                    srcKey +
                    ' and uploaded to ' +
                    dstBucket +
                    '/' +
                    dstKey);
                //@ts-expect-error undefined
            }
            else if (size > 100000) {
                await s3.send(new client_s3_1.PutObjectCommand(destinationParams));
                console.log('Successfully resized small resolution image' +
                    srcBucket +
                    '/' +
                    srcKey +
                    ' and uploaded to ' +
                    dstBucket +
                    '/' +
                    dstKey);
            }
            else {
                console.warn(`${srcKey} object did not have responsive image generated for: ${key}:${value}`);
            }
        }
    }
    catch (error) {
        console.error(error);
        return;
    }
};
exports.handler = handler;
