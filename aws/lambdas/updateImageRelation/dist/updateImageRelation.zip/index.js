"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const supabase_js_1 = require("@supabase/supabase-js");
const client_s3_1 = require("@aws-sdk/client-s3");
const util_1 = __importDefault(require("util"));
const s3 = new client_s3_1.S3Client({ region: 'eu-central-1' });
const handler = async (event) => {
    const supabaseURL = process.env.SUPABASE_DB_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;
    const cloudfrontURL = process.env.CLOUDFRONT_CDN_URL;
    if (!supabaseURL || !supabaseServiceKey) {
        throw new Error('Missing supabase env');
    }
    console.log('Reading options from event:\n', util_1.default.inspect(event, { depth: 5 }));
    const srcBucket = event.Records[0].s3.bucket.name;
    const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const params = {
        Bucket: srcBucket,
        Key: srcKey,
    };
    const response = await s3.send(new client_s3_1.GetObjectCommand(params));
    console.log('Metadata:\n', util_1.default.inspect(response.Metadata, { depth: 5 }));
    if (!response.Metadata) {
        console.error('No metadata set.');
        return;
    }
    const id = response.Metadata.imageid;
    const imageVariant = response.Metadata.imagevariant;
    const supabase = (0, supabase_js_1.createClient)(supabaseURL, supabaseServiceKey);
    try {
        const { error } = await supabase
            .from('Image')
            .update({ [imageVariant]: cloudfrontURL + srcKey })
            .eq('id', id);
        if (error) {
            console.error(error);
        }
    }
    catch (e) {
        console.error(e);
    }
};
exports.handler = handler;
