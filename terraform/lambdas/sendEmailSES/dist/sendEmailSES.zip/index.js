"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_ses_1 = require("@aws-sdk/client-ses");
const supabase_js_1 = require("@supabase/supabase-js");
const ses = new client_ses_1.SESClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const { body, targetUrl, userIdToNotify } = event;
    const supabaseURL = process.env.SUPABASE_DB_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;
    if (!supabaseURL || !supabaseServiceKey) {
        throw new Error('Missing supabase env');
    }
    const supabase = (0, supabase_js_1.createClient)(supabaseURL, supabaseServiceKey);
    const { data, error } = await supabase
        .from('User')
        .select()
        .eq('id', userIdToNotify);
    if (error) {
        console.error(error);
        throw new Error(JSON.stringify(error));
    }
    const templateData = {
        authorOfContent: body.authorOfContent,
        content: body.content,
        targetUrl: `https://annostamps.com${targetUrl}`,
        updateSettingsUrl: `https://annostamps.com/user/${data[0].id}/settings`,
    };
    const command = new client_ses_1.SendTemplatedEmailCommand({
        ConfigurationSetName: 'rendering-failure',
        Destination: {
            ToAddresses: [data[0].email],
        },
        Source: 'AnnoStamps <noreply@email.annostamps.com>',
        Template: 'CommentNotificationTemplate',
        TemplateData: JSON.stringify(templateData),
    });
    try {
        await ses.send(command);
    }
    catch (e) {
        console.error(e);
    }
};
exports.handler = handler;
